public class oops{
    public static void main(String[] args) {

    }
        }
import one.*;
public class ajay {
    public static void main(String[] args) {
        int arr [] ={1,2,3,4};

    }
}
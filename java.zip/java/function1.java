public class function1 {
    public static void jaynt(int a,int b) {
        System.out.println(a+b);
    }
    public static void jaynt(int a, int b, int c) {
        System.out.println(a+b+c);
    }
    public static void main(String[] args) {
        jaynt(11, 11);
        jaynt(11, 11, 11);
    }
    
}

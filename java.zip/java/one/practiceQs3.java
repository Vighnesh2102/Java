package one;

import java.util.Scanner;

//String
public class practiceQs3 {
    public static void main(String[] args) {
        //string declaration
        //String name =" tony";
        //String FullName = "vighnesh vinod bagal";
       // String sentence = "I am bad boy";
        Scanner sc  = new Scanner(System.in);
        String name=sc.nextLine();
        System.out.println("Your name is: "+name);
    }
}

package one;
//defined function in java

public class concatination {
    public static void main(String[] args) {
     /*   String firstname ="tony";
        String lastname = "Stark";
        String fullName = firstname+" "+lastname;
        System.out.println(fullName);
        //length calculte of string
        System.out.println(fullName.length());
        //cahrAt
        for(int i=0;i<fullName.length();i++) {
            System.out.println(fullName.charAt(i));
        }
        //compare string
        //define 2 string
        compareTO funactin cheak '<' '>' '= '

      String name1 = "Tony";
      String name2 ="sahil";
     if(name1.compareTo(name2)==0) {
         System.out.println("strings are equal");

     }
     else {
         System.out.println("Strings are Not equal");
     }
      */
     String  sentence ="tonystark";
     String name = sentence.substring(4);
        System.out.println(name);

        //strings are inmutable
//after decler you can't change string


    }
}

package one;


public class Haybridihertance {
    public static void main(String[] args) {

    }
}

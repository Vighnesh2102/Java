package one;
class  draw{//base class
    String color;
}
class Triangle extends draw { //subclass
}
//Inhertance
//resublity is used
//java 4 types of Inhertance
public class oopes3 
{
 public static void main(String[] args) {
Triangle t1 = new Triangle();
t1.color ="red";
 }   
}

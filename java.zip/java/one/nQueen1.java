package one;

public class nQueen1 {

}

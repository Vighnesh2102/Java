package one;

public class problemQs7 {
    public static void main(String[] args) {
        String name = "kiran";
        String surname ="kiran";
        if(name == surname) {
            System.out.println("strings are equal");
        }
        else {
            System.out.println("Strings are not equal");
        }

    }
}

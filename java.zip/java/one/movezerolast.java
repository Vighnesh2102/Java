package one;

import java.util.Scanner;

public class movezerolast {
    public static void main(String[] args) {

    }
}

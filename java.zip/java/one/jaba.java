package one;

public class jaba {
    public static void main(String args[]) {
        System.out.println("Hallo world");
    }
}

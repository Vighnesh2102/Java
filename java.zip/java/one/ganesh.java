package one;

import java.security.spec.RSAOtherPrimeInfo;

public class ganesh {
    public static void main(String[] args) {
        int arr[][]=new int[2][2];
        int r,c;
        System.out.println("Enter 2*2 Matarix:");

    }
}

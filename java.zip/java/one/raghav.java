package one;

import java.math.*;
import java.time.*;
public class raghav {
    public static void raghv(int x, int y){
      if(x>y) {
          System.out.println("Enmey is their");
      }
      else {
          System.out.println("Enmey is Head");
      }
    }
    public static void main(String[] args) {
        int x =5;
        int y= 6;
        raghv(x, y);
        System.out.println(Math.max(x,y));

    }
}

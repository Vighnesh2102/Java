
import java.net.Socket;

public class Bank{
    public static void Print() {
        System.out.println("Finally executed ");
    }
public static void main(String[] args) {

    Print();
}
}
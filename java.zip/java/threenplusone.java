

public class threenplusone {
    public static void evenodd(int n) {
        do {
            if (n % 2 == 0) {
                n= n / 2;
                System.out.println(n);
            } else if (n % 2 != 0) {
                n= 3 * n + 1;
                System.out.println(n);
            }
        }while(n==1);
    }

    public static void main(String[] args) {
        int arr[] = {11,55,66,77,88,9,4,5,1};

     for(int i =0; i<= arr.length;i++) {



     }

    }
}

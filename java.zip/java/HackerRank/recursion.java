package HackerRank;

public class  recursion {
    public static void printFib(int a, int b, int n) {

    }
    public static void main(String[] args) {
        int a= 0,b =1;

    }
}

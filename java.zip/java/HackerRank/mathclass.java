package HackerRank;
public class mathclass {
    public static void main(String[] args) {
        int a = 5;
        int b = 6;

        System.out.println("Maximum number is; "+Math.max(a,b));
        System.out.println("Minmum Number is: "+Math.min(a,b));

    }
}

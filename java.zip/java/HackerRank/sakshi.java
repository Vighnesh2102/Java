package HackerRank;
public class sakshi {
    public static void main(String[] args) {
        String name = "soham sawant";
        String temp =" ";
        String finalstring= " ";
        String arr[] = new String[name.length()];
        for (int i=0;i<name.length();i++) {
            if(name.charAt(i) ==' '){
                finalstring =temp;
                temp =" ";
            }
            char en = name.charAt(i);

        }
    }
}
